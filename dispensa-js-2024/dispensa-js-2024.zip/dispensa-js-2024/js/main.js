function cambiaColore(){
    let x = document.querySelector('#cambia')
    x.style.backgroundColor='red'
}